package egovframework.com.main.service;

import java.util.HashMap;
import java.util.List;

public interface MainService {

	public List<HashMap<String, Object>> selectStudentInfo();
	
}
